Pomysłodawca Rafał Cichosz (rpce)
Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>